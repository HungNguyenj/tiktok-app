import removeOTPCron from './removeOTPCron';
const startCron = () => {
    removeOTPCron();
};

export default startCron;
